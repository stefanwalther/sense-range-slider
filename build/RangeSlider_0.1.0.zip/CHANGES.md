* **0.1.0**
	* Updated version for Qlik Sense 1.0 (Build Nr. 21)
	* Date: 2014-09-21
* **0.0.1**
	* Initial Version
	* Date: 2014-08-13